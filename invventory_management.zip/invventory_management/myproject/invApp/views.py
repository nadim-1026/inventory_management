
from django.shortcuts import render, redirect
#from .models import ValveSet, Piston, ValvePiece, ValveSetQuantity, PistonQuantity, ValvePieceQuantity
from .forms import ValveSetQuantityForm, PistonForm, ValvePieceForm
from django.contrib import messages
# views.py
from django.shortcuts import render
from django.http import JsonResponse
from rest_framework.decorators import api_view
from rest_framework.response import Response
#from .models import ValveSet, Piston, ValvePiece, ValveSetQuantity, PistonQuantity, ValvePieceQuantity
from .serializers import ValveSetSerializer, PistonSerializer, ValvePieceSerializer
from rest_framework import generics
from .models import ValveSet, Piston, ValvePiece
from .serializers import ValveSetSerializer, PistonSerializer, ValvePieceSerializer
# views.py
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import ValveSet, Piston, ValvePiece,ValveSetQuantity
from .serializers import ValveSetSerializer, PistonSerializer, ValvePieceSerializer,ValveSetQuantitySerializer
from rest_framework import status





@api_view(['PUT'])
def update_piston(request):
    piston_id = request.data.get('piston_id')

    try:
        piston = Piston.objects.get(pk=piston_id)
    except Piston.DoesNotExist:
        return Response({'error': 'Piston not found'}, status=status.HTTP_404_NOT_FOUND)

    # Assuming request.data contains the updated data for the piston
    serializer = PistonSerializer(piston, data=request.data, partial=True)

    if serializer.is_valid():
        serializer.save()
        return Response({'success': True})
    else:
        return Response({'error': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
def get_valve_piece(request, valve_piece_id):
    valve_piece = ValvePiece.objects.get(pk=valve_piece_id)
    serializer = ValvePieceSerializer(valve_piece)
    return Response(serializer.data)

@api_view(['PUT'])
def update_valve_piece(request):
    valve_piece_id = request.data.get('valve_piece_id')

    try:
        valve_piece = ValvePiece.objects.get(pk=valve_piece_id)
    except ValvePiece.DoesNotExist:
        return Response({'error': 'ValvePiece not found'}, status=status.HTTP_404_NOT_FOUND)

    # Assuming request.data contains the updated data for the valve piece
    serializer = ValvePieceSerializer(valve_piece, data=request.data, partial=True)

    if serializer.is_valid():
        serializer.save()
        return Response({'success': True})
    else:
        return Response({'error': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)



@api_view(['GET'])
def get_all_valve_sets(request):
    valve_sets = ValveSet.objects.all()
    print(valve_sets)
    serializer = ValveSetSerializer(valve_sets, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def get_piston(request):
    print("chetan")
    pistons=Piston.objects.all()
    serializer = PistonSerializer(pistons, many=True)
    return serializer.data


from rest_framework import status

@api_view(['PUT'])
def update_valve_set_quantity(request):
    valve_set_id = request.data.get('valve_set_id')

    try:
        valve_set_quantity = ValveSetQuantity.objects.get(pk=valve_set_id)
    except ValveSetQuantity.DoesNotExist:
        return Response({'error': 'ValveSetQuantity not found'}, status=status.HTTP_404_NOT_FOUND)

    # Assuming request.data contains the updated data for the valve set quantity
    serializer = ValveSetQuantitySerializer(valve_set_quantity, data=request.data, partial=True)

    if serializer.is_valid():
        serializer.save()
        return Response({'success': True})
    else:
        return Response({'error': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


class ValveSetListCreateView(generics.ListCreateAPIView):
    queryset = ValveSet.objects.all()
    serializer_class = ValveSetSerializer


class PistonRetrieveUpdateView(generics.RetrieveUpdateAPIView):
    queryset = Piston.objects.all()
    print(queryset)
    serializer_class = PistonSerializer


class ValvePieceRetrieveUpdateView(generics.RetrieveUpdateAPIView):
    queryset = ValvePiece.objects.all()
    serializer_class = ValvePieceSerializer


def index(request):
    valve_sets = ValveSet.objects.all()
    pistons = Piston.objects.all()
    valve_pieces = ValvePiece.objects.all()

    if request.method == 'POST':
        valve_set_quantity_form = ValveSetQuantityForm(request.POST)
        piston_quantity_form = PistonForm(request.POST)
        valve_piece_quantity_form = ValvePieceForm(request.POST)

        forms = {
            'valve_set_quantity_form': valve_set_quantity_form,
            'piston_quantity_form': piston_quantity_form,
            'valve_piece_quantity_form': valve_piece_quantity_form,
        }

        if all(form.is_valid() for form in forms.values()):
            valve_set_quantity_form.save()
            piston_quantity_form.save()
            valve_piece_quantity_form.save()
            # Add success message or redirection logic here

        else:
            # Handle errors for each form
            for form_name, form in forms.items():
                if not form.is_valid():
                    # You can add custom error messages or log errors here
                    print(f"{form_name} has errors:", form.errors)

                    # Update the context to include the form with errors
                    context = {
                        'valve_sets': valve_sets,
                        'pistons': pistons,
                        'valve_pieces': valve_pieces,
                        'valve_set_quantity_form': forms['valve_set_quantity_form'],
                        'piston_quantity_form': forms['piston_quantity_form'],
                        'valve_piece_quantity_form': forms['valve_piece_quantity_form'],
                    }

                    # Render the template with the updated context
                    print(valve_sets)
                    return render(request, 'index.html', context)
    else:
        valve_set_quantity_form = ValveSetQuantityForm()
        piston_quantity_form = PistonForm()
        valve_piece_quantity_form = ValvePieceForm()

    context = {
        'valve_sets': valve_sets,
        'pistons': pistons,
        'valve_pieces': valve_pieces,
        'valve_set_quantity_form': valve_set_quantity_form,
        'piston_quantity_form': piston_quantity_form,
        'valve_piece_quantity_form': valve_piece_quantity_form,
    }

    return render(request, 'index.html', context)


from django.shortcuts import render

# Create your views here.

# get -> data fetch
# put => data update
# post -> new data create
# delete -> data delete
