from django.urls import path
from .controllers import get_all_valve_sets
from .views import get_piston, update_piston, get_valve_piece, update_valve_piece, update_valve_set_quantity
from . import views
from .views import ValveSetListCreateView, PistonRetrieveUpdateView, ValvePieceRetrieveUpdateView
from django.db.utils import OperationalError

urlpatterns = [
    path('api/v1/valvesets/', get_all_valve_sets),
    path('', views.index, name='index'),
    path('api/v1/valvesets/', ValveSetListCreateView.as_view(), name='valveset-list-create'),
    path('api/v1/pistons/<int:pk>/', PistonRetrieveUpdateView.as_view(), name='piston-retrieve-update'),
    path('api/v1/valve-pieces/<int:pk>/', ValvePieceRetrieveUpdateView.as_view(), name='valvepiece-retrieve-update'),
    path('api/v1/pistons/<str:piston_id>/', update_piston),
    path('api/v1/valve-pieces/<str:valve_piece_id>/', get_valve_piece),
    path('api/v1/valve-pieces/', update_valve_piece),
    path('api/v1/valvesetquantity/', update_valve_set_quantity),
    path('api/v1/get-pistons/<str:piston_id>/', get_piston),
    # Add more URL patterns for other views as needed...
]
