


const getAllValveSets = async()=>{
    try {
        let response = await fetch('http://127.0.0.1:8000/api/v1/valvesets/');
        if(!response) return;
        response  = await response.json();

        if(!response.success)
        {
            console.log(response.message);
            return;
        }
        return response.data;
    } catch (error) {
        console.log("Async Error Found: ",  error);
    }
};


const getPiston = async(pistonId)=>{
    try {
        let response = await fetch(`http://localhost:4000/api/v1/pistons/${pistonId}`);
        if(!response) return;
        response = await response.json();

        if(!response.success)
        {
            console.log(response.message);
            return;
        }

        return response.data;

    } catch (error) {
        console.log("Async Error Found: ",  error);
    }
}

const getValvePiece = async(valvePieceId)=>{
    try {
        let response = await fetch(`http://localhost:4000/api/v1/valve-pieces/${valvePieceId}`);
        if(!response) return;
        response = await response.json();

        if(!response.success)
        {
            console.log(response.message);
            return;
        }

        return response.data;

    } catch (error) {
        console.log("Async Error Found: ",  error);
    }
}



const  updatePiston = async(piston)=>{
    try {
        let response = await fetch(`http://localhost:4000/api/v1/pistons`, {
            method : "PUT",
            body : JSON.stringify({
                "piston" : piston
            }),
            headers: {
                "Content-type": "application/json"
            }
        });
        if(!response) return;
        response = await response.json();

        if(!response.success)
        {
            console.log(response.message);
            return;
        }

        return response.success;

    } catch (error) {
        console.log("Async Error Found: ",  error);
        return false;
    }
}

const updateValvePiece = async(valvePiece)=>{
    try {
        let response = await fetch(`http://localhost:4000/api/v1/valve-pieces`, {
            method : "PUT",
            body : JSON.stringify({
                "valvePiece" : valvePiece
            }),
            headers: {
                "Content-type": "application/json"
            }
        });
        if(!response) return;
        response = await response.json();

        if(!response.success)
        {
            console.log(response.message);
            return;
        }

        return response.success;

    } catch (error) {
        console.log("Async Error Found: ",  error);
        return false;
    }
}


const updateValveSetQuantity = async(valveSet)=>{
    try {
        let response = await fetch('api/v1/valvesets/', {
            method : "PUT",
            body : JSON.stringify({
                "valveSet" : valveSet
            }),
            headers: {
                "Content-type": "application/json"
            }
        });
        if(!response) return;
        response = await response.json();

        if(!response.success)
        {
            console.log(response.message);
            return;
        }

        return response.success;

    } catch (error) {
        console.log("Async Error Found: ",  error);
        return false;
    }
}