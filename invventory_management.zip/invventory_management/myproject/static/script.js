console.log("Enter");

let pistonQuantityInputDiv = document.getElementById('piston-quantity-input-div');
let valvePieceQuantityInputDiv = document.getElementById('valve-piece-quantity-input-div');
let errorBarDiv = document.getElementById('error-bar-div');


// INPUT FIELDS
let valveSetInput = document.getElementById('input-valve-set');
let valveSetQuantityInput = document.getElementById('input-valve-set-quantity');
let pistonInput = document.getElementById('input-piston');
let valvePieceInput = document.getElementById('input-valve-piece');


let valveSetList = [];
let selectedValveSet, selectedPiston, selectedValvePiece;



renderInitialFields();
renderInputFields();

////////////////////////// RENDERS //////////////////////////////////////////////////////
async function renderInitialFields()
{
    consloe.log("called");

    refreshValveSets().then(()=>{
    consloe.log("done");
        valveSetInput.innerHTML = `<option selected disabled value="">Select Valve Set</option>`;
        pistonInput.innerHTML = `<option selected disabled value="">Select Piston</option>`;
        valvePieceInput.innerHTML =  `<option selected disabled value="">Select Valve Piece</option>`;


        if(!valveSetList) return;
        valveSetList.forEach(({valve_set_id, piston_id, valve_piece_id})=>{
            valveSetInput.innerHTML += `<option value="${valve_set_id}">${valve_set_id}</option>`;
            pistonInput.innerHTML += `<option value="${piston_id}">${piston_id}</option>`;
            valvePieceInput.innerHTML += `<option value="${valve_piece_id}">${valve_piece_id}</option>`;
        })
    });
}




function renderInputFields()
{
    pistonQuantityInputDiv.innerHTML = `<hr><p class="text-center fw-bold fs-5 text-uppercase">Piston Quantity</p>`;
    valvePieceQuantityInputDiv.innerHTML = `<hr ><p class="text-center fw-bold fs-5 text-uppercase">VALVE PIECE Quantity</p>`;

    for(let count = 1; count <= 15; count++)
    {
        pistonQuantityInputDiv.innerHTML += `<div class="d-flex gap-3 align-items-center my-3">
        <label for="input-valve-piece" class="form-label text-nowrap m-0 fw-bold">${count}</label>
        <input class="form-control" type="number" id="p-${count}" placeholder="Piston ${count} Quantity" value="${selectedPiston?selectedPiston['piston_subtype_'+count]:""}">
        </div>`;


        valvePieceQuantityInputDiv.innerHTML += `<div class="d-flex gap-3 align-items-center my-3">
        <label for="input-valve-piece" class="form-label text-nowrap m-0 fw-bold">${count}</label>
        <input class="form-control" type="number" id="vp-${count}" placeholder="Valve Piece ${count} Quantity" value="${selectedValvePiece?selectedValvePiece['valve_piece_subtype_'+count]:""}">
        </div>`;
    }
}


function showMessage(type, message, delay=1500, afterMessage)
{

    if(!type || !{message}) return;


    errorBarDiv.innerHTML = `<div class="alert alert-${type} text-center fw-bold">${message}</div>`;
    errorBarDiv.classList.remove('d-none');
    document.body.scrollTop = document.documentElement.scrollTop = 0;

    setTimeout(()=>{
        errorBarDiv.classList.add('d-none');
        if(afterMessage) afterMessage();
    }, delay);
}

function addErrorInput(inputFields, errrMessage="Invalid Input !")
{
    if(!inputFields) return;

    inputFields.forEach(inputField => {
        inputField.classList.add('border');
        inputField.classList.add('border-danger');
    });


    showMessage("danger", errrMessage, 3000, ()=>{
        inputFields.forEach(inputField => {
            inputField.classList.remove('border');
            inputField.classList.remove('border-danger');
        });
    });
}


//////////////////////  SUBMIT & VALIDATIONS ///////////////////////////////////
async function submitData()
{
    if(!validated())
    {
        return;
    }

    if(await submitPiston() && await  submitValvePiece() && await submitValveSetQuantity())
    {
        showMessage("success", "Submit Successful !", 2000);
    }
    else
    {
        showMessage("danger", "Submit unsuccessful !", 2000)
    }
}

async function submitValveSetQuantity(){
    let valveSet = {
        valve_set_id : selectedValveSet.valve_set_id,
        piston_id : selectedPiston.piston_id,
        valve_piece_id : selectedValvePiece.valve_piece_id,
        valve_set_quantity : valveSetQuantityInput.value
    }

    let response =  await updateValveSetQuantity(valveSet);
    return response;
}

async function submitPiston(){
    try {
        for(let count = 1; count <= 15; count++)
        {
            selectedPiston['piston_subtype_'+count] = parseInt(document.getElementById(`p-${count}`).value);
        }

        let response =  await updatePiston(selectedPiston);
        return response;

    } catch (error) {
        return false;
    }
}

async function submitValvePiece()
{
    try {
        for(let count = 1; count <= 15; count++)
        {
            selectedValvePiece['valve_piece_subtype_'+count] = parseInt(document.getElementById(`vp-${count}`).value);
        }
        let response =  await updateValvePiece(selectedValvePiece);
        return response;
    } catch (error) {
        return false;
    }
}

function validated()
{
    let erroredInputFields = [];
    if(valveSetInput.value === "")
    {
        erroredInputFields.push(valveSetInput);
    }

    if(valveSetQuantityInput.value === "")
    {
        erroredInputFields.push(valveSetQuantityInput);
    }

    if(pistonInput.value === "")
    {
        erroredInputFields.push(pistonInput);
    }
    if(valvePieceInput.value === "")
    {
        erroredInputFields.push(valvePieceInput);
    }

    // piston quantity and valve set quantity input validations
    let pQuantity,  vpQuantity;
    for(let count = 1; count <= 15; count++)
    {
        pQuantity = document.getElementById(`p-${count}`);
        vpQuantity = document.getElementById(`vp-${count}`);
        if(pQuantity.value === "")
        {
            erroredInputFields.push(pQuantity)
        }
        if(vpQuantity.value === "")
        {
            erroredInputFields.push(vpQuantity)
        }
    }

    addErrorInput(erroredInputFields, "Invalid input fields !!");

    return erroredInputFields.length==0;
}






////////////////////////////// CHANGE HANDLERS /////////////////////////////////

async function valveSetChangeHandler(newValveSetID)
{
    refreshValveSets().then(()=>{
        selectedValveSet = valveSetList.find((valveSet)=>valveSet.valve_set_id === newValveSetID);
        console.log(selectedValveSet);
        valveSetQuantityInput.value = selectedValveSet.valve_set_quantity;
        valvePieceInput.value = "";
        pistonInput.value = "";
        selectedPiston = undefined;
        selectedValvePiece = undefined
        clearInputs();
    });
}


async function pistonChangeHandler(newPistonValue)
{
    clearInputs();
    selectedPiston =  await getPiston(newPistonValue);
    if(!selectedPiston) return;
    renderInputFields();
}

async function valvePieceChangeHandler(newValvePieceValue)
{
    clearInputs();

    selectedValvePiece = await getValvePiece(newValvePieceValue);

    if(!selectedValvePiece) return;

    renderInputFields();
}

function clearInputs()
{
    for(let count = 1; count <= 15; count++)
    {
        document.getElementById(`p-${count}`).value = "";
        document.getElementById(`vp-${count}`).value = "";
    }
}



/////////////////////// DATABASE CHANGES ////////////


async function refreshValveSets()
{
    valveSetList = await getAllValveSets();
}